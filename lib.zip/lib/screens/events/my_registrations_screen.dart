import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../services/event_service.dart';

class MyRegistrationsScreen extends StatelessWidget {
  const MyRegistrationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final service = EventService();

    return StreamBuilder<List<MyRegistration>>(
      stream: service.streamMyRegistrations(),
      initialData: const [],
      builder: (context, snap) {
        if (snap.hasError) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text(
                'Error cargando tus registros:\n${snap.error}',
                textAlign: TextAlign.center,
              ),
            ),
          );
        }

        final regs = snap.data ?? const [];

        if (snap.connectionState == ConnectionState.waiting && regs.isEmpty) {
          return const Center(child: CircularProgressIndicator());
        }

        if (regs.isEmpty) {
          return const Center(child: Text('Aún no estás registrado en ningún evento.'));
        }

        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: regs.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, i) {
            final r = regs[i];

            final start = r.eventStartAt == null ? '' : _fmt(r.eventStartAt!);
            final subtitle = [
              if (r.eventLocation?.isNotEmpty == true) r.eventLocation!,
              if (start.isNotEmpty) start,
            ].join(' • ');

            return Card(
              child: ListTile(
                title: Text(r.eventTitle ?? 'Evento (${r.eventId})'),
                subtitle: Text(subtitle.isEmpty ? 'ID: ${r.eventId}' : subtitle),
                trailing: TextButton.icon(
                  onPressed: () async {
                    try {
                      await service.unregisterFromEvent(r.eventId);
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Registro cancelado')),
                        );
                      }
                    } catch (e) {
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(e.toString().replaceFirst('Exception: ', '')),
                          ),
                        );
                      }
                    }
                  },
                  icon: const Icon(Icons.close),
                  label: const Text('Cancelar'),
                ),
              ),
            );
          },
        );
      },
    );
  }

  static String _fmt(DateTime d) {
    final two = (int x) => x.toString().padLeft(2, '0');
    return '${two(d.day)}/${two(d.month)}/${d.year} ${two(d.hour)}:${two(d.minute)}';
  }
}

/// Modelo simple para pintar "Mis registros"
class MyRegistration {
  final String eventId;
  final String? eventTitle;
  final String? eventLocation;
  final DateTime? eventStartAt;
  final DateTime? eventEndAt;

  MyRegistration({
    required this.eventId,
    this.eventTitle,
    this.eventLocation,
    this.eventStartAt,
    this.eventEndAt,
  });

  static MyRegistration fromDoc(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data();

    DateTime? ts(dynamic x) {
      if (x is Timestamp) return x.toDate();
      if (x is DateTime) return x;
      return null;
    }

    return MyRegistration(
      eventId: (d['eventId'] ?? '').toString().isNotEmpty
          ? (d['eventId'] ?? '').toString()
          : _inferEventIdFromPath(doc.reference.path),
      eventTitle: d['eventTitle']?.toString(),
      eventLocation: d['eventLocation']?.toString(),
      eventStartAt: ts(d['eventStartAt']),
      eventEndAt: ts(d['eventEndAt']),
    );
  }

  // fallback: .../events/{eventId}/registrations/{uid}
  static String _inferEventIdFromPath(String path) {
    final parts = path.split('/');
    final idx = parts.indexOf('events');
    if (idx != -1 && idx + 1 < parts.length) return parts[idx + 1];
    return '';
  }
}
